KINESIS_RECORDS = {
    "Records": [
        {
            "kinesis": {
                "data": "ewogICJ1c2VyX3V1aWQiOiAiMTIzMyIsCiAgInBlcmNlbnRhZ2VfY29tcGxldGVkX2luX2NvdXJzZSI6IDkwLAogICJjb21wbGV0ZWRfbGVzc29uc19pbl9jb3Vyc2UiOiAyLAogICJudW1iZXJfb2ZfbGVzc29uc19pbl9jb3Vyc2UiOiA1LAogICJjb3Vyc2VfdGl0bGUiOiAiTGVhcm4gZW5nbGlzaCIsCiAgImNvdXJzZV91dWlkIjogIjQ0NDQiLAogICJsYW5ndWFnZSI6ICJlbmdsaXNoIiwKICAidGl0bGUiOiAiMXN0IGxlc3NvbiIsCiAgImNvbnRlbnRfcmVsZWFzZV9pZCI6ICIyMDIwIgp9"
            }}
    ]
}
